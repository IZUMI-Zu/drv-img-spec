"""This module contains the logger for the project."""

import logging

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
