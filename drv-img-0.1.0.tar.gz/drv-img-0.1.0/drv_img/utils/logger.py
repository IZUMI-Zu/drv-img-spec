import logging

logger = logging.getLogger()
logger.setLevel(logging.DEBUG)
