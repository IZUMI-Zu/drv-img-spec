from enum import Enum


class ArchType(Enum):
    X86_64 = 'x86_64'
    ARM64 = 'aarch64'
