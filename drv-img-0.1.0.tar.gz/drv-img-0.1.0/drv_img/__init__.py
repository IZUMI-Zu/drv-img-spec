"""
drv-img: a tool to add package and driver to iso image"

"""

__cli_name__ = 'drv-img'
__version__ = '0.1.0'
__date__ = '2023-09-07'
__author__ = 'BINSHUO ZU'
__licence__ = 'GPLv2'
